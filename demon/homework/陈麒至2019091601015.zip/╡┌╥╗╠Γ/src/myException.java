/**
 * @Project: selflearn-2
 * @Package: PACKAGE_NAME
 * @Author: Chen Qizhi
 * @Date: 2020/12/25  周五
 * @Time: 9:06
 **/

public class myException extends Throwable{
    public myException(){}

    public myException(String msg){
        super(msg);
    }
}
